type IntroLine = { kind: "cmd" | "out"; text: string };

const TYPE_DELAY_MS = 28;
const LINE_DELAY_MS = 220;
const SEEN_KEY = "introSeen";

function must<T extends Element>(selector: string, root: ParentNode = document): T {
  const el = root.querySelector<T>(selector);
  if (!el) throw new Error(`Missing required element: ${selector}`);
  return el;
}

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

function readYear(value: string | undefined, name: string): number {
  const n = Number(value);
  if (!Number.isInteger(n)) throw new Error(`${name} must be an integer, got: ${value}`);
  return n;
}

async function runIntro(): Promise<void> {
  const intro = must<HTMLElement>("#intro");
  const term = must<HTMLElement>("#intro-term");
  const skip = must<HTMLButtonElement>("#intro-skip");

  const finish = () => {
    intro.classList.add("done");
    document.body.classList.remove("intro-active");
    sessionStorage.setItem(SEEN_KEY, "1");
  };

  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (sessionStorage.getItem(SEEN_KEY) || reduced) {
    finish();
    return;
  }

  let skipped = false;
  skip.addEventListener("click", () => {
    skipped = true;
    finish();
  });

  const lines = JSON.parse(must<HTMLScriptElement>("#intro-lines").textContent) as IntroLine[];

  for (const line of lines) {
    if (skipped) return;
    const row = document.createElement("div");
    term.appendChild(row);

    if (line.kind === "out") {
      row.textContent = line.text;
      await sleep(LINE_DELAY_MS);
      continue;
    }

    const prompt = document.createElement("span");
    prompt.className = "prompt";
    prompt.textContent = "user@host:$ ";
    const typed = document.createElement("span");
    typed.className = "cursor";
    row.append(prompt, typed);

    for (const ch of line.text) {
      if (skipped) return;
      typed.textContent += ch;
      await sleep(TYPE_DELAY_MS);
    }
    typed.classList.remove("cursor");
    await sleep(LINE_DELAY_MS);
  }

  if (!skipped) finish();
}

function initTimelines(): void {
  for (const timeline of document.querySelectorAll<HTMLElement>(".timeline")) {
    const from = readYear(timeline.dataset.from, "timeline data-from");
    const to = readYear(timeline.dataset.to, "timeline data-to");
    if (to <= from) throw new Error("timeline data-to must be greater than data-from");

    must<HTMLElement>(".timeline-year-start", timeline).textContent = String(from);
    must<HTMLElement>(".timeline-year-end", timeline).textContent = String(to);

    for (const node of timeline.querySelectorAll<HTMLElement>(".timeline-node")) {
      const start = readYear(node.dataset.start, "timeline-node data-start");
      const pct = ((start - from) / (to - from)) * 100;
      if (pct < 0 || pct > 100) {
        throw new Error(`Timeline node start ${start} is outside ${from}-${to}`);
      }
      node.style.setProperty("--pos", `${pct.toFixed(2)}%`);
    }
  }
}

function initSections(): void {
  const sections = [...document.querySelectorAll<HTMLElement>("[data-section]")];
  if (sections.length === 0) throw new Error("No [data-section] elements found");

  const links = [...document.querySelectorAll<HTMLAnchorElement>("a[data-nav]")];
  const dotsList = must<HTMLOListElement>("#dots");
  const dots = new Map<string, HTMLButtonElement>();

  const goTo = (id: string, smooth: boolean) => {
    const target = document.getElementById(id);
    if (!target) throw new Error(`No section with id: ${id}`);
    target.scrollIntoView({ behavior: smooth ? "smooth" : "auto" });
    history.replaceState(null, "", `#${id}`);
  };

  for (const section of sections) {
    const li = document.createElement("li");
    const btn = document.createElement("button");
    btn.type = "button";
    btn.setAttribute("aria-label", section.id);
    btn.addEventListener("click", () => goTo(section.id, true));
    li.appendChild(btn);
    dotsList.appendChild(li);
    dots.set(section.id, btn);
  }

  for (const link of links) {
    link.addEventListener("click", (ev) => {
      ev.preventDefault();
      goTo(link.hash.slice(1), true);
    });
  }
  must<HTMLAnchorElement>(".nav-brand").addEventListener("click", (ev) => {
    ev.preventDefault();
    goTo(sections[0]!.id, true);
  });

  const setActive = (id: string) => {
    for (const [sid, btn] of dots) btn.classList.toggle("active", sid === id);
    for (const link of links) link.classList.toggle("active", link.hash === `#${id}`);
  };

  const observer = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        if (entry.isIntersecting) setActive(entry.target.id);
      }
    },
    { threshold: 0.6 },
  );
  sections.forEach((s) => observer.observe(s));

  if (location.hash.length > 1) goTo(location.hash.slice(1), false);
}

initTimelines();
initSections();
void runIntro();
